# Nodus — Brand Assets

Identity for **Nodus**, the network system-of-record by SecuraIT.
Topology mapping · SNMP · syslog · IPAM · alerting · ISP circuit inventory.

---

## 1. The idea

The mark is a **trefoil knot** — the simplest knot that cannot be untied.
*Nodus* is Latin for knot, and a trefoil is also the smallest graph that
genuinely crosses itself: a path that returns through its own topology.

The wordmark is drawn with the **same pen weight and the same round
terminals as the mark**, so the whole identity reads as one continuous
strand of cable. That is the rule to protect — if you re-set the wordmark
in an off-the-shelf typeface, the idea breaks.

Deliberately *not*: a shield, a globe, a hexagon, a padlock, or a
hub-and-spoke starburst. Every competitor in this category owns one of those.

---

## 2. Colour

Palette is derived from **T568B copper pair insulation** — the colour code
every network engineer already has memorised. Green pair is primary
(it is also the link-light), brown pair is the warm secondary.

| Token | Hex | Role |
|---|---|---|
| `--nodus-ink` | `#161A21` | Warm graphite. Primary surface, dark UI, logo on light. |
| `--nodus-green` | `#2BA24E` | Green pair. Primary brand colour on light surfaces. |
| `--nodus-green-bright` | `#45C46B` | Green pair, raised. Logo + accents on dark surfaces. |
| `--nodus-copper` | `#8A5433` | Brown pair. Secondary accent, chart series 2. |
| `--nodus-amber` | `#E0902B` | Alarm / degraded state **only**. Never decorative. |
| `--nodus-paper` | `#F2F3EF` | Light surface. |

Note the discipline: amber is reserved for state. If amber appears in
marketing chrome, an engineer scanning a dashboard learns to ignore it.

```css
:root {
  --nodus-ink: #161A21;
  --nodus-green: #2BA24E;
  --nodus-green-bright: #45C46B;
  --nodus-copper: #8A5433;
  --nodus-amber: #E0902B;
  --nodus-paper: #F2F3EF;
}
```

```ts
// tailwind.config.ts
import type { Config } from "tailwindcss";

export default {
  theme: {
    extend: {
      colors: {
        nodus: {
          ink: "#161A21",
          green: "#2BA24E",
          "green-bright": "#45C46B",
          copper: "#8A5433",
          amber: "#E0902B",
          paper: "#F2F3EF",
        },
      },
    },
  },
} satisfies Config;
```

---

## 3. Typography

| Role | Face | Notes |
|---|---|---|
| Display / headings | **Archivo Expanded** (600–700) | Wide, industrial, technical without being a monospace cliché. |
| Body / UI | **Archivo** (400–500) | Same superfamily, so headings and body stay related. |
| Data, ports, IPs, OIDs | **IBM Plex Mono** (400) | Tabular figures. Use for anything an engineer will compare column-wise. |

All three are on Google Fonts under the OFL — no licensing cost.

```ts
// app/layout.tsx
import { Archivo, IBM_Plex_Mono } from "next/font/google";

const archivo = Archivo({
  subsets: ["latin"],
  variable: "--font-archivo",
  axes: ["wdth"],
});

const plexMono = IBM_Plex_Mono({
  subsets: ["latin"],
  weight: ["400", "500"],
  variable: "--font-plex-mono",
});
```

Always set `font-variant-numeric: tabular-nums` on IP addresses, interface
counters, and circuit IDs so digits don't shift as values update.

---

## 4. Usage rules

- **Clear space** — leave at least the height of the `O` on every side.
- **Minimum size** — full lockup no smaller than 96 px wide; below that use
  the mark alone.
- **Colour** — both `nodus-mark.svg` and `nodus-logo.svg` use `currentColor`.
  Set the colour on the parent: `text-nodus-ink` on light, `text-nodus-green-bright`
  on dark. Do not hard-code fills.
- **The under-crossings are real transparent gaps** (SVG mask, not painted
  casings), so the mark sits correctly on photos, gradients, and any surface.
- **Never**: stretch, add a gradient, add a drop shadow, outline it, rotate it,
  or place it inside a container shape other than the supplied favicon tile.

---

## 5. Source

### Mark (`nodus-mark.svg`)

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" fill="none" role="img" aria-label="Nodus">
  <title>Nodus</title>
  <defs>
    <mask id="m-knot" maskUnits="userSpaceOnUse" x="0" y="0" width="100" height="100">
      <rect width="100" height="100" fill="#000"/>
      <path d="M 50.00 43.01 C 51.14 43.09 54.61 43.18 56.85 43.51 C 59.09 43.84 61.33 44.35 63.44 45.00 C 65.56 45.64 67.62 46.46 69.54 47.39 C 71.45 48.32 73.27 49.41 74.91 50.58 C 76.55 51.75 78.06 53.06 79.37 54.41 C 80.68 55.76 81.83 57.22 82.76 58.68 C 83.70 60.15 84.45 61.69 84.98 63.20 C 85.51 64.70 85.84 66.25 85.95 67.72 C 86.07 69.20 85.97 70.67 85.68 72.04 C 85.38 73.40 84.87 74.72 84.19 75.91 C 83.51 77.09 82.61 78.19 81.58 79.13 C 80.55 80.07 79.32 80.89 77.98 81.53 C 76.65 82.16 75.15 82.65 73.58 82.95 C 72.00 83.24 70.29 83.36 68.56 83.29 C 66.82 83.21 64.98 82.94 63.16 82.49 C 61.34 82.03 59.45 81.37 57.62 80.54 C 55.78 79.70 53.93 78.67 52.17 77.48 C 50.41 76.28 48.66 74.90 47.05 73.39 C 45.43 71.89 43.87 70.20 42.46 68.43 C 41.06 66.65 39.75 64.72 38.60 62.75 C 37.46 60.77 36.11 57.60 35.62 56.57" fill="none" stroke="#000" stroke-width="19.0" stroke-linecap="round"/>
      <path d="M 50.00 43.01 C 51.14 43.09 54.61 43.18 56.85 43.51 C 59.09 43.84 61.33 44.35 63.44 45.00 C 65.56 45.64 67.62 46.46 69.54 47.39 C 71.45 48.32 73.27 49.41 74.91 50.58 C 76.55 51.75 78.06 53.06 79.37 54.41 C 80.68 55.76 81.83 57.22 82.76 58.68 C 83.70 60.15 84.45 61.69 84.98 63.20 C 85.51 64.70 85.84 66.25 85.95 67.72 C 86.07 69.20 85.97 70.67 85.68 72.04 C 85.38 73.40 84.87 74.72 84.19 75.91 C 83.51 77.09 82.61 78.19 81.58 79.13 C 80.55 80.07 79.32 80.89 77.98 81.53 C 76.65 82.16 75.15 82.65 73.58 82.95 C 72.00 83.24 70.29 83.36 68.56 83.29 C 66.82 83.21 64.98 82.94 63.16 82.49 C 61.34 82.03 59.45 81.37 57.62 80.54 C 55.78 79.70 53.93 78.67 52.17 77.48 C 50.41 76.28 48.66 74.90 47.05 73.39 C 45.43 71.89 43.87 70.20 42.46 68.43 C 41.06 66.65 39.75 64.72 38.60 62.75 C 37.46 60.77 36.11 57.60 35.62 56.57" fill="none" stroke="#fff" stroke-width="11.0" stroke-linecap="round"/>
      <path d="M 38.60 62.75 C 38.11 61.72 36.45 58.67 35.62 56.57 C 34.78 54.46 34.10 52.27 33.61 50.11 C 33.11 47.96 32.78 45.76 32.63 43.64 C 32.48 41.52 32.51 39.39 32.70 37.39 C 32.90 35.39 33.27 33.42 33.79 31.61 C 34.30 29.80 34.99 28.08 35.79 26.54 C 36.60 25.00 37.56 23.58 38.60 22.36 C 39.64 21.15 40.81 20.09 42.03 19.25 C 43.25 18.42 44.58 17.77 45.90 17.34 C 47.23 16.91 48.63 16.69 50.00 16.69 C 51.37 16.69 52.77 16.91 54.10 17.34 C 55.42 17.77 56.75 18.42 57.97 19.25 C 59.19 20.09 60.36 21.15 61.40 22.36 C 62.44 23.58 63.40 25.00 64.21 26.54 C 65.01 28.08 65.70 29.80 66.21 31.61 C 66.73 33.42 67.10 35.39 67.30 37.39 C 67.49 39.39 67.52 41.52 67.37 43.64 C 67.22 45.76 66.89 47.96 66.39 50.11 C 65.90 52.27 65.22 54.46 64.38 56.57 C 63.55 58.67 62.54 60.77 61.40 62.75 C 60.25 64.72 58.18 67.48 57.54 68.43" fill="none" stroke="#000" stroke-width="19.0" stroke-linecap="round"/>
      <path d="M 38.60 62.75 C 38.11 61.72 36.45 58.67 35.62 56.57 C 34.78 54.46 34.10 52.27 33.61 50.11 C 33.11 47.96 32.78 45.76 32.63 43.64 C 32.48 41.52 32.51 39.39 32.70 37.39 C 32.90 35.39 33.27 33.42 33.79 31.61 C 34.30 29.80 34.99 28.08 35.79 26.54 C 36.60 25.00 37.56 23.58 38.60 22.36 C 39.64 21.15 40.81 20.09 42.03 19.25 C 43.25 18.42 44.58 17.77 45.90 17.34 C 47.23 16.91 48.63 16.69 50.00 16.69 C 51.37 16.69 52.77 16.91 54.10 17.34 C 55.42 17.77 56.75 18.42 57.97 19.25 C 59.19 20.09 60.36 21.15 61.40 22.36 C 62.44 23.58 63.40 25.00 64.21 26.54 C 65.01 28.08 65.70 29.80 66.21 31.61 C 66.73 33.42 67.10 35.39 67.30 37.39 C 67.49 39.39 67.52 41.52 67.37 43.64 C 67.22 45.76 66.89 47.96 66.39 50.11 C 65.90 52.27 65.22 54.46 64.38 56.57 C 63.55 58.67 62.54 60.77 61.40 62.75 C 60.25 64.72 58.18 67.48 57.54 68.43" fill="none" stroke="#fff" stroke-width="11.0" stroke-linecap="round"/>
      <path d="M 61.40 62.75 C 60.75 63.69 58.94 66.65 57.54 68.43 C 56.13 70.20 54.57 71.89 52.95 73.39 C 51.34 74.90 49.59 76.28 47.83 77.48 C 46.07 78.67 44.22 79.70 42.38 80.54 C 40.55 81.37 38.66 82.03 36.84 82.49 C 35.02 82.94 33.18 83.21 31.44 83.29 C 29.71 83.36 28.00 83.24 26.42 82.95 C 24.85 82.65 23.35 82.16 22.02 81.53 C 20.68 80.89 19.45 80.07 18.42 79.13 C 17.39 78.19 16.49 77.09 15.81 75.91 C 15.13 74.72 14.62 73.40 14.32 72.04 C 14.03 70.67 13.93 69.20 14.05 67.72 C 14.16 66.25 14.49 64.70 15.02 63.20 C 15.55 61.69 16.30 60.15 17.24 58.68 C 18.17 57.22 19.32 55.76 20.63 54.41 C 21.94 53.06 23.45 51.75 25.09 50.58 C 26.73 49.41 28.55 48.32 30.46 47.39 C 32.38 46.46 34.44 45.64 36.56 45.00 C 38.67 44.35 40.91 43.84 43.15 43.51 C 45.39 43.18 47.72 43.01 50.00 43.01 C 52.28 43.01 55.71 43.43 56.85 43.51" fill="none" stroke="#000" stroke-width="19.0" stroke-linecap="round"/>
      <path d="M 61.40 62.75 C 60.75 63.69 58.94 66.65 57.54 68.43 C 56.13 70.20 54.57 71.89 52.95 73.39 C 51.34 74.90 49.59 76.28 47.83 77.48 C 46.07 78.67 44.22 79.70 42.38 80.54 C 40.55 81.37 38.66 82.03 36.84 82.49 C 35.02 82.94 33.18 83.21 31.44 83.29 C 29.71 83.36 28.00 83.24 26.42 82.95 C 24.85 82.65 23.35 82.16 22.02 81.53 C 20.68 80.89 19.45 80.07 18.42 79.13 C 17.39 78.19 16.49 77.09 15.81 75.91 C 15.13 74.72 14.62 73.40 14.32 72.04 C 14.03 70.67 13.93 69.20 14.05 67.72 C 14.16 66.25 14.49 64.70 15.02 63.20 C 15.55 61.69 16.30 60.15 17.24 58.68 C 18.17 57.22 19.32 55.76 20.63 54.41 C 21.94 53.06 23.45 51.75 25.09 50.58 C 26.73 49.41 28.55 48.32 30.46 47.39 C 32.38 46.46 34.44 45.64 36.56 45.00 C 38.67 44.35 40.91 43.84 43.15 43.51 C 45.39 43.18 47.72 43.01 50.00 43.01 C 52.28 43.01 55.71 43.43 56.85 43.51" fill="none" stroke="#fff" stroke-width="11.0" stroke-linecap="round"/>
    </mask>
  </defs>
  <rect width="100" height="100" fill="currentColor" mask="url(#m-knot)"/>
</svg>
```

### Horizontal lockup (`nodus-logo.svg`)

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 322 72.7" fill="none" role="img" aria-label="Nodus">
  <title>Nodus</title>
  <defs>
    <mask id="l-knot" maskUnits="userSpaceOnUse" x="0" y="0" width="100" height="100">
      <rect width="100" height="100" fill="#000"/>
      <path d="M 50.00 43.01 C 51.14 43.09 54.61 43.18 56.85 43.51 C 59.09 43.84 61.33 44.35 63.44 45.00 C 65.56 45.64 67.62 46.46 69.54 47.39 C 71.45 48.32 73.27 49.41 74.91 50.58 C 76.55 51.75 78.06 53.06 79.37 54.41 C 80.68 55.76 81.83 57.22 82.76 58.68 C 83.70 60.15 84.45 61.69 84.98 63.20 C 85.51 64.70 85.84 66.25 85.95 67.72 C 86.07 69.20 85.97 70.67 85.68 72.04 C 85.38 73.40 84.87 74.72 84.19 75.91 C 83.51 77.09 82.61 78.19 81.58 79.13 C 80.55 80.07 79.32 80.89 77.98 81.53 C 76.65 82.16 75.15 82.65 73.58 82.95 C 72.00 83.24 70.29 83.36 68.56 83.29 C 66.82 83.21 64.98 82.94 63.16 82.49 C 61.34 82.03 59.45 81.37 57.62 80.54 C 55.78 79.70 53.93 78.67 52.17 77.48 C 50.41 76.28 48.66 74.90 47.05 73.39 C 45.43 71.89 43.87 70.20 42.46 68.43 C 41.06 66.65 39.75 64.72 38.60 62.75 C 37.46 60.77 36.11 57.60 35.62 56.57" fill="none" stroke="#000" stroke-width="19.0" stroke-linecap="round"/>
      <path d="M 50.00 43.01 C 51.14 43.09 54.61 43.18 56.85 43.51 C 59.09 43.84 61.33 44.35 63.44 45.00 C 65.56 45.64 67.62 46.46 69.54 47.39 C 71.45 48.32 73.27 49.41 74.91 50.58 C 76.55 51.75 78.06 53.06 79.37 54.41 C 80.68 55.76 81.83 57.22 82.76 58.68 C 83.70 60.15 84.45 61.69 84.98 63.20 C 85.51 64.70 85.84 66.25 85.95 67.72 C 86.07 69.20 85.97 70.67 85.68 72.04 C 85.38 73.40 84.87 74.72 84.19 75.91 C 83.51 77.09 82.61 78.19 81.58 79.13 C 80.55 80.07 79.32 80.89 77.98 81.53 C 76.65 82.16 75.15 82.65 73.58 82.95 C 72.00 83.24 70.29 83.36 68.56 83.29 C 66.82 83.21 64.98 82.94 63.16 82.49 C 61.34 82.03 59.45 81.37 57.62 80.54 C 55.78 79.70 53.93 78.67 52.17 77.48 C 50.41 76.28 48.66 74.90 47.05 73.39 C 45.43 71.89 43.87 70.20 42.46 68.43 C 41.06 66.65 39.75 64.72 38.60 62.75 C 37.46 60.77 36.11 57.60 35.62 56.57" fill="none" stroke="#fff" stroke-width="11.0" stroke-linecap="round"/>
      <path d="M 38.60 62.75 C 38.11 61.72 36.45 58.67 35.62 56.57 C 34.78 54.46 34.10 52.27 33.61 50.11 C 33.11 47.96 32.78 45.76 32.63 43.64 C 32.48 41.52 32.51 39.39 32.70 37.39 C 32.90 35.39 33.27 33.42 33.79 31.61 C 34.30 29.80 34.99 28.08 35.79 26.54 C 36.60 25.00 37.56 23.58 38.60 22.36 C 39.64 21.15 40.81 20.09 42.03 19.25 C 43.25 18.42 44.58 17.77 45.90 17.34 C 47.23 16.91 48.63 16.69 50.00 16.69 C 51.37 16.69 52.77 16.91 54.10 17.34 C 55.42 17.77 56.75 18.42 57.97 19.25 C 59.19 20.09 60.36 21.15 61.40 22.36 C 62.44 23.58 63.40 25.00 64.21 26.54 C 65.01 28.08 65.70 29.80 66.21 31.61 C 66.73 33.42 67.10 35.39 67.30 37.39 C 67.49 39.39 67.52 41.52 67.37 43.64 C 67.22 45.76 66.89 47.96 66.39 50.11 C 65.90 52.27 65.22 54.46 64.38 56.57 C 63.55 58.67 62.54 60.77 61.40 62.75 C 60.25 64.72 58.18 67.48 57.54 68.43" fill="none" stroke="#000" stroke-width="19.0" stroke-linecap="round"/>
      <path d="M 38.60 62.75 C 38.11 61.72 36.45 58.67 35.62 56.57 C 34.78 54.46 34.10 52.27 33.61 50.11 C 33.11 47.96 32.78 45.76 32.63 43.64 C 32.48 41.52 32.51 39.39 32.70 37.39 C 32.90 35.39 33.27 33.42 33.79 31.61 C 34.30 29.80 34.99 28.08 35.79 26.54 C 36.60 25.00 37.56 23.58 38.60 22.36 C 39.64 21.15 40.81 20.09 42.03 19.25 C 43.25 18.42 44.58 17.77 45.90 17.34 C 47.23 16.91 48.63 16.69 50.00 16.69 C 51.37 16.69 52.77 16.91 54.10 17.34 C 55.42 17.77 56.75 18.42 57.97 19.25 C 59.19 20.09 60.36 21.15 61.40 22.36 C 62.44 23.58 63.40 25.00 64.21 26.54 C 65.01 28.08 65.70 29.80 66.21 31.61 C 66.73 33.42 67.10 35.39 67.30 37.39 C 67.49 39.39 67.52 41.52 67.37 43.64 C 67.22 45.76 66.89 47.96 66.39 50.11 C 65.90 52.27 65.22 54.46 64.38 56.57 C 63.55 58.67 62.54 60.77 61.40 62.75 C 60.25 64.72 58.18 67.48 57.54 68.43" fill="none" stroke="#fff" stroke-width="11.0" stroke-linecap="round"/>
      <path d="M 61.40 62.75 C 60.75 63.69 58.94 66.65 57.54 68.43 C 56.13 70.20 54.57 71.89 52.95 73.39 C 51.34 74.90 49.59 76.28 47.83 77.48 C 46.07 78.67 44.22 79.70 42.38 80.54 C 40.55 81.37 38.66 82.03 36.84 82.49 C 35.02 82.94 33.18 83.21 31.44 83.29 C 29.71 83.36 28.00 83.24 26.42 82.95 C 24.85 82.65 23.35 82.16 22.02 81.53 C 20.68 80.89 19.45 80.07 18.42 79.13 C 17.39 78.19 16.49 77.09 15.81 75.91 C 15.13 74.72 14.62 73.40 14.32 72.04 C 14.03 70.67 13.93 69.20 14.05 67.72 C 14.16 66.25 14.49 64.70 15.02 63.20 C 15.55 61.69 16.30 60.15 17.24 58.68 C 18.17 57.22 19.32 55.76 20.63 54.41 C 21.94 53.06 23.45 51.75 25.09 50.58 C 26.73 49.41 28.55 48.32 30.46 47.39 C 32.38 46.46 34.44 45.64 36.56 45.00 C 38.67 44.35 40.91 43.84 43.15 43.51 C 45.39 43.18 47.72 43.01 50.00 43.01 C 52.28 43.01 55.71 43.43 56.85 43.51" fill="none" stroke="#000" stroke-width="19.0" stroke-linecap="round"/>
      <path d="M 61.40 62.75 C 60.75 63.69 58.94 66.65 57.54 68.43 C 56.13 70.20 54.57 71.89 52.95 73.39 C 51.34 74.90 49.59 76.28 47.83 77.48 C 46.07 78.67 44.22 79.70 42.38 80.54 C 40.55 81.37 38.66 82.03 36.84 82.49 C 35.02 82.94 33.18 83.21 31.44 83.29 C 29.71 83.36 28.00 83.24 26.42 82.95 C 24.85 82.65 23.35 82.16 22.02 81.53 C 20.68 80.89 19.45 80.07 18.42 79.13 C 17.39 78.19 16.49 77.09 15.81 75.91 C 15.13 74.72 14.62 73.40 14.32 72.04 C 14.03 70.67 13.93 69.20 14.05 67.72 C 14.16 66.25 14.49 64.70 15.02 63.20 C 15.55 61.69 16.30 60.15 17.24 58.68 C 18.17 57.22 19.32 55.76 20.63 54.41 C 21.94 53.06 23.45 51.75 25.09 50.58 C 26.73 49.41 28.55 48.32 30.46 47.39 C 32.38 46.46 34.44 45.64 36.56 45.00 C 38.67 44.35 40.91 43.84 43.15 43.51 C 45.39 43.18 47.72 43.01 50.00 43.01 C 52.28 43.01 55.71 43.43 56.85 43.51" fill="none" stroke="#fff" stroke-width="11.0" stroke-linecap="round"/>
    </mask>
  </defs>
  <g transform="scale(0.7273)">
    <rect width="100" height="100" fill="currentColor" mask="url(#l-knot)"/>
  </g>
  <g transform="translate(88 12.36)" stroke="currentColor" stroke-width="8" stroke-linecap="round" stroke-linejoin="round" fill="none">
    <path d="M 4 44 L 4 4 L 32 44 L 32 4"/>
    <ellipse cx="66" cy="24" rx="14" ry="20"/>
    <path d="M 100 44 L 100 4 L 104 4 A 20 20 0 0 1 104 44 Z"/>
    <path d="M 148 4 L 148 30 A 14 14 0 0 0 176 30 L 176 4"/>
    <path d="M 224 14 C 224 6.5 215 4 210 4 C 202 4 196 8.5 196 14 C 196 20 202 23 210 24 C 218 25 224 28 224 34 C 224 39.5 218 44 210 44 C 204 44 196 41 196 34"/>
  </g>
</svg>
```

### Favicon (`favicon.svg`)

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" role="img" aria-label="Nodus">
  <title>Nodus</title>
  <defs>
    <mask id="f-knot" maskUnits="userSpaceOnUse" x="0" y="0" width="100" height="100">
      <rect width="100" height="100" fill="#000"/>
      <path d="M 50.00 43.01 C 51.14 43.09 54.61 43.18 56.85 43.51 C 59.09 43.84 61.33 44.35 63.44 45.00 C 65.56 45.64 67.62 46.46 69.54 47.39 C 71.45 48.32 73.27 49.41 74.91 50.58 C 76.55 51.75 78.06 53.06 79.37 54.41 C 80.68 55.76 81.83 57.22 82.76 58.68 C 83.70 60.15 84.45 61.69 84.98 63.20 C 85.51 64.70 85.84 66.25 85.95 67.72 C 86.07 69.20 85.97 70.67 85.68 72.04 C 85.38 73.40 84.87 74.72 84.19 75.91 C 83.51 77.09 82.61 78.19 81.58 79.13 C 80.55 80.07 79.32 80.89 77.98 81.53 C 76.65 82.16 75.15 82.65 73.58 82.95 C 72.00 83.24 70.29 83.36 68.56 83.29 C 66.82 83.21 64.98 82.94 63.16 82.49 C 61.34 82.03 59.45 81.37 57.62 80.54 C 55.78 79.70 53.93 78.67 52.17 77.48 C 50.41 76.28 48.66 74.90 47.05 73.39 C 45.43 71.89 43.87 70.20 42.46 68.43 C 41.06 66.65 39.75 64.72 38.60 62.75 C 37.46 60.77 36.11 57.60 35.62 56.57" fill="none" stroke="#000" stroke-width="24.0" stroke-linecap="round"/>
      <path d="M 50.00 43.01 C 51.14 43.09 54.61 43.18 56.85 43.51 C 59.09 43.84 61.33 44.35 63.44 45.00 C 65.56 45.64 67.62 46.46 69.54 47.39 C 71.45 48.32 73.27 49.41 74.91 50.58 C 76.55 51.75 78.06 53.06 79.37 54.41 C 80.68 55.76 81.83 57.22 82.76 58.68 C 83.70 60.15 84.45 61.69 84.98 63.20 C 85.51 64.70 85.84 66.25 85.95 67.72 C 86.07 69.20 85.97 70.67 85.68 72.04 C 85.38 73.40 84.87 74.72 84.19 75.91 C 83.51 77.09 82.61 78.19 81.58 79.13 C 80.55 80.07 79.32 80.89 77.98 81.53 C 76.65 82.16 75.15 82.65 73.58 82.95 C 72.00 83.24 70.29 83.36 68.56 83.29 C 66.82 83.21 64.98 82.94 63.16 82.49 C 61.34 82.03 59.45 81.37 57.62 80.54 C 55.78 79.70 53.93 78.67 52.17 77.48 C 50.41 76.28 48.66 74.90 47.05 73.39 C 45.43 71.89 43.87 70.20 42.46 68.43 C 41.06 66.65 39.75 64.72 38.60 62.75 C 37.46 60.77 36.11 57.60 35.62 56.57" fill="none" stroke="#fff" stroke-width="15.0" stroke-linecap="round"/>
      <path d="M 38.60 62.75 C 38.11 61.72 36.45 58.67 35.62 56.57 C 34.78 54.46 34.10 52.27 33.61 50.11 C 33.11 47.96 32.78 45.76 32.63 43.64 C 32.48 41.52 32.51 39.39 32.70 37.39 C 32.90 35.39 33.27 33.42 33.79 31.61 C 34.30 29.80 34.99 28.08 35.79 26.54 C 36.60 25.00 37.56 23.58 38.60 22.36 C 39.64 21.15 40.81 20.09 42.03 19.25 C 43.25 18.42 44.58 17.77 45.90 17.34 C 47.23 16.91 48.63 16.69 50.00 16.69 C 51.37 16.69 52.77 16.91 54.10 17.34 C 55.42 17.77 56.75 18.42 57.97 19.25 C 59.19 20.09 60.36 21.15 61.40 22.36 C 62.44 23.58 63.40 25.00 64.21 26.54 C 65.01 28.08 65.70 29.80 66.21 31.61 C 66.73 33.42 67.10 35.39 67.30 37.39 C 67.49 39.39 67.52 41.52 67.37 43.64 C 67.22 45.76 66.89 47.96 66.39 50.11 C 65.90 52.27 65.22 54.46 64.38 56.57 C 63.55 58.67 62.54 60.77 61.40 62.75 C 60.25 64.72 58.18 67.48 57.54 68.43" fill="none" stroke="#000" stroke-width="24.0" stroke-linecap="round"/>
      <path d="M 38.60 62.75 C 38.11 61.72 36.45 58.67 35.62 56.57 C 34.78 54.46 34.10 52.27 33.61 50.11 C 33.11 47.96 32.78 45.76 32.63 43.64 C 32.48 41.52 32.51 39.39 32.70 37.39 C 32.90 35.39 33.27 33.42 33.79 31.61 C 34.30 29.80 34.99 28.08 35.79 26.54 C 36.60 25.00 37.56 23.58 38.60 22.36 C 39.64 21.15 40.81 20.09 42.03 19.25 C 43.25 18.42 44.58 17.77 45.90 17.34 C 47.23 16.91 48.63 16.69 50.00 16.69 C 51.37 16.69 52.77 16.91 54.10 17.34 C 55.42 17.77 56.75 18.42 57.97 19.25 C 59.19 20.09 60.36 21.15 61.40 22.36 C 62.44 23.58 63.40 25.00 64.21 26.54 C 65.01 28.08 65.70 29.80 66.21 31.61 C 66.73 33.42 67.10 35.39 67.30 37.39 C 67.49 39.39 67.52 41.52 67.37 43.64 C 67.22 45.76 66.89 47.96 66.39 50.11 C 65.90 52.27 65.22 54.46 64.38 56.57 C 63.55 58.67 62.54 60.77 61.40 62.75 C 60.25 64.72 58.18 67.48 57.54 68.43" fill="none" stroke="#fff" stroke-width="15.0" stroke-linecap="round"/>
      <path d="M 61.40 62.75 C 60.75 63.69 58.94 66.65 57.54 68.43 C 56.13 70.20 54.57 71.89 52.95 73.39 C 51.34 74.90 49.59 76.28 47.83 77.48 C 46.07 78.67 44.22 79.70 42.38 80.54 C 40.55 81.37 38.66 82.03 36.84 82.49 C 35.02 82.94 33.18 83.21 31.44 83.29 C 29.71 83.36 28.00 83.24 26.42 82.95 C 24.85 82.65 23.35 82.16 22.02 81.53 C 20.68 80.89 19.45 80.07 18.42 79.13 C 17.39 78.19 16.49 77.09 15.81 75.91 C 15.13 74.72 14.62 73.40 14.32 72.04 C 14.03 70.67 13.93 69.20 14.05 67.72 C 14.16 66.25 14.49 64.70 15.02 63.20 C 15.55 61.69 16.30 60.15 17.24 58.68 C 18.17 57.22 19.32 55.76 20.63 54.41 C 21.94 53.06 23.45 51.75 25.09 50.58 C 26.73 49.41 28.55 48.32 30.46 47.39 C 32.38 46.46 34.44 45.64 36.56 45.00 C 38.67 44.35 40.91 43.84 43.15 43.51 C 45.39 43.18 47.72 43.01 50.00 43.01 C 52.28 43.01 55.71 43.43 56.85 43.51" fill="none" stroke="#000" stroke-width="24.0" stroke-linecap="round"/>
      <path d="M 61.40 62.75 C 60.75 63.69 58.94 66.65 57.54 68.43 C 56.13 70.20 54.57 71.89 52.95 73.39 C 51.34 74.90 49.59 76.28 47.83 77.48 C 46.07 78.67 44.22 79.70 42.38 80.54 C 40.55 81.37 38.66 82.03 36.84 82.49 C 35.02 82.94 33.18 83.21 31.44 83.29 C 29.71 83.36 28.00 83.24 26.42 82.95 C 24.85 82.65 23.35 82.16 22.02 81.53 C 20.68 80.89 19.45 80.07 18.42 79.13 C 17.39 78.19 16.49 77.09 15.81 75.91 C 15.13 74.72 14.62 73.40 14.32 72.04 C 14.03 70.67 13.93 69.20 14.05 67.72 C 14.16 66.25 14.49 64.70 15.02 63.20 C 15.55 61.69 16.30 60.15 17.24 58.68 C 18.17 57.22 19.32 55.76 20.63 54.41 C 21.94 53.06 23.45 51.75 25.09 50.58 C 26.73 49.41 28.55 48.32 30.46 47.39 C 32.38 46.46 34.44 45.64 36.56 45.00 C 38.67 44.35 40.91 43.84 43.15 43.51 C 45.39 43.18 47.72 43.01 50.00 43.01 C 52.28 43.01 55.71 43.43 56.85 43.51" fill="none" stroke="#fff" stroke-width="15.0" stroke-linecap="round"/>
    </mask>
  </defs>
  <rect width="100" height="100" rx="22" fill="#161A21"/>
  <g transform="translate(9 9) scale(0.82)">
    <rect width="100" height="100" fill="#45C46B" mask="url(#f-knot)"/>
  </g>
</svg>
```

---

## 6. React component

```tsx
// components/brand/NodusLogo.tsx
import type { SVGProps } from "react";

type Variant = "lockup" | "mark";

interface NodusLogoProps extends SVGProps<SVGSVGElement> {
  /** `lockup` renders mark + wordmark; `mark` renders the knot alone. */
  variant?: Variant;
}

/**
 * Nodus brand logo.
 *
 * Colour is inherited from `currentColor`, so set it with a text utility on
 * the element or an ancestor, e.g. `className="text-nodus-green-bright"`.
 * The knot's under-crossings are transparent gaps, so the mark composites
 * correctly over any background.
 */
export function NodusLogo({ variant = "lockup", ...props }: NodusLogoProps) {
  return variant === "mark" ? <NodusMark {...props} /> : <NodusLockup {...props} />;
}
```

Drop the two inner components straight from the SVG source in section 5.
Give each `<mask>` a unique `id` (or generate one with React's `useId`) if
more than one logo can appear on the same page — duplicate mask ids in a
single document will cause one of them to render as a solid block.

---

## 7. Favicon wiring (Next.js App Router)

Copy `favicon/` into `app/` and Next will pick most of it up automatically.
For explicit control:

```tsx
// app/layout.tsx
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: { default: "Nodus", template: "%s · Nodus" },
  description:
    "Know what's on your network, where it lives, and who provides the circuit.",
  icons: {
    icon: [
      { url: "/favicon.svg", type: "image/svg+xml" },
      { url: "/favicon-32x32.png", sizes: "32x32", type: "image/png" },
      { url: "/favicon-16x16.png", sizes: "16x16", type: "image/png" },
    ],
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180" }],
    shortcut: ["/favicon.ico"],
  },
  manifest: "/site.webmanifest",
};
```

Plain HTML equivalent:

```html
<link rel="icon" href="/favicon.svg" type="image/svg+xml" />
<link rel="icon" href="/favicon-32x32.png" sizes="32x32" type="image/png" />
<link rel="icon" href="/favicon-16x16.png" sizes="16x16" type="image/png" />
<link rel="apple-touch-icon" href="/apple-touch-icon.png" sizes="180x180" />
<link rel="manifest" href="/site.webmanifest" />
<meta name="theme-color" content="#161A21" />
```

---

## 8. Files

```
nodus-brand/
├── svg/
│   ├── nodus-logo.svg          horizontal lockup, currentColor
│   ├── nodus-mark.svg          knot only, currentColor
│   └── favicon.svg             green knot on ink tile, rounded
├── favicon/
│   ├── favicon.ico             16 / 32 / 48 multi-resolution
│   ├── favicon.svg
│   ├── favicon-16x16.png
│   ├── favicon-32x32.png
│   ├── favicon-48x48.png
│   ├── favicon-96x96.png
│   ├── favicon-192x192.png
│   ├── favicon-512x512.png
│   ├── apple-touch-icon.png    180x180, full-bleed (iOS masks it itself)
│   └── site.webmanifest
├── nodus-logo-ink.png          1600px, transparent
├── nodus-mark-ink.png          512px, transparent
└── NODUS-BRAND.md              this file
```
